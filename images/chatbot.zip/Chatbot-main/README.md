# Chatbot

#To Setup That Project In your pc 

First open Xampp and start apache and MySQL Then click on Admin nearby the config button of MySQL.

Follow those Steps :

- step 1: create a database named "bot".
- step 2: then Create a table Named "chatbot".
- step 3: Set 3 column and set Name These Columns accordingly "id" , "queries" , "replies".
- step 4: Insert Values Into Table By Clicking On Insert option at top. 
- step 5: Write a value into value Column (What you Wanna Reply when you enter Your Query) Save That Values In table.
